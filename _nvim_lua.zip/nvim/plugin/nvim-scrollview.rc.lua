require('scrollview').setup({
  excluded_filetypes = {'nerdtree'},
  current_only = true,
  winblend = 75,
  base = 'buffer',
  column = 120
})