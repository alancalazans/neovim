--[[
 __          __   __        __                   
|  \        |  \ |  \      |  \                  
 \▓▓_______  \▓▓_| ▓▓_     | ▓▓__    __  ______  
|  \       \|  \   ▓▓ \    | ▓▓  \  |  \|      \ 
| ▓▓ ▓▓▓▓▓▓▓\ ▓▓\▓▓▓▓▓▓    | ▓▓ ▓▓  | ▓▓ \▓▓▓▓▓▓\
| ▓▓ ▓▓  | ▓▓ ▓▓ | ▓▓ __   | ▓▓ ▓▓  | ▓▓/      ▓▓
| ▓▓ ▓▓  | ▓▓ ▓▓ | ▓▓|  \__| ▓▓ ▓▓__/ ▓▓  ▓▓▓▓▓▓▓
| ▓▓ ▓▓  | ▓▓ ▓▓  \▓▓  ▓▓  \ ▓▓\▓▓    ▓▓\▓▓    ▓▓
 \▓▓\▓▓   \▓▓\▓▓   \▓▓▓▓ \▓▓\▓▓ \▓▓▓▓▓▓  \▓▓▓▓▓▓▓
                                  
	File: init.lua
	Author: Alan Calazans <alancalazans.50@gmail.com>
	Created: Seg 06 Mar 2023
	Updated: Seg 06 Mar 2023
	Installation: As dotfile drop the file into your $HOME/.config/nvim/ folder.
	License: GNU General Public License v3
	         <http://www.gnu.org/licenses/gpl.html>
	Version: 1.0
]]

-- Arquivos de configuração básica
require('base')
require('highlights')
require('maps')
require('plugins')

local has = vim.fn.has
local is_mac = has "macunix"
local is_linux = has "linux"
local is_win = has "win32"
local is_wsl = has "wsl"

if is_mac then
  require('os.macos')
end
if is_linux then
  require('os.linux')
end
if is_win then
  require('os.windows')
end
if is_wsl then
  require('os.wsl')
end	

-- Plugins
