-- Neovim API aliases
local cmd = vim.cmd
local exec = vim.api.nvim_exec
local fn = vim.fn
local g = vim.g
local opt = vim.opt
local scriptencoding = vim.scriptencoding

cmd([[
	"---------------------------------------
	" Suporte a cores.
	"---------------------------------------
	if $TERM !=? 'xterm-256color'
		set termguicolors
	endif
	"---------------------------------------
	" Suporte ao itálico verdadeiro
	"---------------------------------------
	let &t_ZH="\e[3m"
	let &t_ZR="\e[23m"
	set noautochdir " Definir diretorio atual automaticamente
	set nostartofline " Não resetar o cursor para o inicio da linha
	set autoread " Ler arquivo automaticamente caso ele for modificado externamente
	set ai " Ao criar nova linha, usa indentação da linha anterior
	set nocompatible
	set ruler " show the cursor position all the time
	set showmatch " Faz o highlight do parênteses, colechetes ou chave correspondente
	"---------------------------------------
	" Alguns tipos de arquivos devem ser ignorados pelo Vim.
	"---------------------------------------
	set wildignore=*.o,*.obj,*.bak,*.exe,*.dll,*.com,*.class,*.au,*.wav,*.ps,*.avi,*.wmv,*.flv,*.djvu,*.pdf,*.chm,*.dvi,*.svn/,*~
	"---------------------------------------
	" Autocompletar html, css, javascript, php.
	"---------------------------------------
	filetype on
	if has('autocmd')
		filetype plugin indent on
		"           │     │    └──── Enable file type detection
		"           │     └───────── Enable loading of indent file
		"           └─────────────── Enable loading of plugin files
		autocmd FileType javascript set complete-=k/home/$USER/.vim/doc/js-list.txt complete+=k/home/$USER/.vim/doc/js-list.txt
		autocmd FileType php set complete-=k/home/$USER/.vim/doc/php-list.txt complete+=k/home/$USER/.vim/doc/php-list.txt
		autocmd FileType css set complete-=k/home/$USER/.vim/doc/css-list.txt complete+=k/home/$USER/.vim/doc/css-list.txt
		autocmd FileType nim :set expandtab
	endif
	set omnifunc=syntaxcomplete#Complete
	au FileType python set omnifunc=pythoncomplete#Complete
	au FileType javascript set omnifunc=javascriptcomplete#CompleteJS
	au FileType html,xhtml set omnifunc=htmlcomplete#CompleteTags
	au FileType css set omnifunc=csscomplete#CompleteCSS
	au FileType xml set omnifunc=xmlcomplete#CompleteTags
	au FileType php set omnifunc=phpcomplete#CompletePHP
	au FileType c set omnifunc=ccomplete#Complete
	" adiciona omnifunc para demais formatos
	if has("autocmd") && exists("+omnifunc")
		autocmd Filetype *
		\ if &omnifunc == "" |
		\  setlocal omnifunc=syntaxcomplete#Complete |
		\ endif
	endif
	setlocal sm " Destaca Abertura e fechamento {} [] ()
	"---------------------------------------
	" Definindo sintaxe para algumas extenções.
	"---------------------------------------
	au BufRead,BufNewFile *.phtml set filetype=php
	au BufRead,BufNewFile *.ejs set filetype=html
	au BufRead,BufNewFile *.ep set filetype=html
	au BufRead,BufNewFile *.pl6 set filetype=perl
	au BufRead,BufNewFile *.raku set filetype=perl
	au BufRead,BufNewFile *.ts set filetype=javascript
	au BufRead,BufNewFile *.go set filetype=go
	au BufRead,BufNewFile *.exs setf erlang
	au BufRead,BufNewFile *.ex setf erlang
	"---------------------------------------
	" Folding / Unfolding
	"---------------------------------------
	setlocal foldmethod=indent
	set nofoldenable
	set foldlevel=99
	set fillchars=fold:\ "The backslash escapes a space
	set foldtext=CustomFoldText()
	function! CustomFoldText()
		let indentation = indent(v:foldstart - 1)
		let foldSize = 1 + v:foldend - v:foldstart
		let foldSizeStr = " " . foldSize . " lines "
		let foldLevelStr = repeat("+--", v:foldlevel)
		let expansionString = repeat(" ", indentation)
		return expansionString . foldLevelStr . foldSizeStr
	endfunction
]])

-- General Setup
g.mapleader = " "

-- UI
cmd("autocmd!")

scriptencoding = 'utf-8'
opt.encoding = 'utf-8'
opt.fileencoding = 'utf-8'

vim.wo.number = true

opt.title = true
opt.autoindent = true
opt.smartindent = true
opt.mouse = 'a'
opt.hlsearch = true
opt.backup = false
opt.showcmd = true
opt.cmdheight = 1
opt.laststatus = 2
opt.expandtab = true
opt.scrolloff = 10
opt.shell = 'fish'
opt.backupskip = { '/tmp/*', '/private/tmp/*' }
opt.inccommand = 'split'
opt.ignorecase = true -- Case insensitive searching UNLESS /C or capital in search
opt.smarttab = true
opt.breakindent = true
opt.shiftwidth = 2
opt.tabstop = 2
opt.wrap = true -- Wrap lines
opt.backspace = { 'start', 'eol', 'indent' }
opt.path:append { '**' } -- Finding files - Search down into subfolders
opt.wildignore:append { '*/node_modules/*' }

-- Undercurl
cmd([[let &t_Cs = "\e[4:3m"]])
cmd([[let &t_Ce = "\e[4:0m"]])

-- Turn off paste mode when leaving insert
vim.api.nvim_create_autocmd("InsertLeave", {
  pattern = '*',
  command = "set nopaste"
})

-- Add asterisks in block comments
opt.formatoptions:append { 'r' }

-- Indentation guides
opt.termguicolors = true
cmd [[highlight IndentBlanklineIndent1 guifg=#E06C75 gui=nocombine]]
cmd [[highlight IndentBlanklineIndent2 guifg=#E5C07B gui=nocombine]]
cmd [[highlight IndentBlanklineIndent3 guifg=#98C379 gui=nocombine]]
cmd [[highlight IndentBlanklineIndent4 guifg=#56B6C2 gui=nocombine]]
cmd [[highlight IndentBlanklineIndent5 guifg=#61AFEF gui=nocombine]]
cmd [[highlight IndentBlanklineIndent6 guifg=#C678DD gui=nocombine]]

opt.list = true
--opt.listchars:append "space:⋅"
--opt.listchars:append "eol:↴"

require("indent_blankline").setup {
	space_char_blankline = " ",
	char_highlight_list = {
		"IndentBlanklineIndent1",
		"IndentBlanklineIndent2",
		"IndentBlanklineIndent3",
		"IndentBlanklineIndent4",
		"IndentBlanklineIndent5",
		"IndentBlanklineIndent6",
	},
}
