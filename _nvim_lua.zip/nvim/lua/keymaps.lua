-- Aliases
local map = vim.api.nvim_set_keymap
local default_opts = {noremap = true, silent = true}
local cmd = vim.cmd
-- Mapeamento das teclas
map('', '<up>', '<nop>', {noremap = true})
map('', '<down>', '<nop>', {noremap = true})
map('', '<left>', '<nop>', {noremap = true})
map('', '<right>', '<nop>', {noremap = true})

map('i', '<C-h>', '<left>', {noremap = true})
map('i', '<C-j>', '<up>', {noremap = true})
map('i', '<C-k>', '<down>', {noremap = true})
map('i', '<C-l>', '<right>', {noremap = true})