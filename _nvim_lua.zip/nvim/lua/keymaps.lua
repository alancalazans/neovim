local map = vim.api.nvim_set_keymap
local keymap = vim.keymap
local opts = { noremap = true, silent = true }
local cmd = vim.cmd

cmd([[
	"---------------------------------------
	" Atalhos comuns de teclado
	" Permite selecionar com SHIFT + SETA como no Windows
	"---------------------------------------
	set selectmode=mouse,key
	set mousemodel=popup
	set keymodel=startsel,stopsel
	set selection=exclusive
  "---------------------------------------
  " CTRL-S salva
  "---------------------------------------
  nmap <c-s> :w<cr>
  vmap <c-s> <c-c>:update<cr>
  imap <c-s> <c-o>:w<cr>
  "---------------------------------------
  " CTRL-Z desfaz
  "---------------------------------------
  nmap <c-z> u
  vmap <c-z> <c-c>u
  imap <c-z> <c-o>u
  "---------------------------------------
  " CTRL-Y refaz
  "---------------------------------------
  nmap <c-y> <c-r>
  vmap <c-y> <c-c><c-r>
  imap <c-y> <c-o><c-r>
  "---------------------------------------
  " Fechar Editor
  "---------------------------------------
  nmap <c-q> :q<cr>
  vmap <c-q> <c-c>:q<cr>
  imap <c-q> <c-o>:q<cr>
  "---------------------------------------
  "<Ctrl-X> -- cut (goto visual mode and cut)
  "---------------------------------------
  imap <C-X> <C-O>vgG
  vmap <C-X> "*x<Esc>i
  nmap <C-X> <c-x> <c-o>
  "---------------------------------------
  "<Ctrl-C> -- copy (goto visual mode and copy)
  "---------------------------------------
  imap <C-C> <C-O>vgG
  vmap <C-C> "*y<Esc>i
  "---------------------------------------
  "<Ctrl-A> -- copy all
  "---------------------------------------
  "imap <C-A> <C-O>gg<C-O>gH<C-O>G<Esc>
  "vmap <C-A> <Esc>gggH<C-O>G<Esc>i
  "---------------------------------------
  "<Ctrl-V> -- paste
  "---------------------------------------
  nm \\paste\\ "=@*.'xy'<CR>gPFx"_2x:echo<CR>
  imap <C-V> x<Esc>\\paste\\"_s
  vmap <C-V> "-cx<Esc>\\paste\\"_x
  "---------------------------------------
  " Movimentação de bloco de texto selecionado
  "---------------------------------------
  " Move bloco de texto selecionado pra cima
  function! MoveUp()
    let end=line("'>")
    let start=line("'<")
    if (start > 1)
      let dif=end - start
      exec "'<,'>d"
      exec "normal kP"
      exec "normal " . (start-1) . "GV" . (end-1) . "G"
      else
      exec "normal " . (start) . "GV" . (end) . "G"
    endif
  endfunction
  " Move bloco de texto selecionado para baixo
  function! MoveDown()
    let end=line("'>")
    let start=line("'<")
    if (end < line("$")-1)
      let dif=end - start
      exec "'<,'>d"
      exec "normal p" . (start+1) . "GV" . (end+1) . "G"
    else
      exec "normal " . (start) . "GV" . (end) . "G"
    endif
  endfunction
  " Duplica um bloco de texto
  function! Duplicate()
    let end=line("'>")
    let start=line("'<")
    let dif=end - start
    exec "'<,'>y"
    exec "normal " . end . "G"
    exec "normal p"
    exec "normal " . (start+dif+1) . "GV" . (end+dif+1) . "G"
  endfunction
  " Move bloco de texto selecionado pra cima
  vmap <c-s-up> :<c-u> call MoveUp()<cr>
  " Move bloco de texto selecionado pra baixo
  vmap <c-s-down> :<c-u>call MoveDown()<cr>
  " Duplica o bloco de texto selecionado
  vmap <c-d> :<c-u>call Duplicate()<cr>
  "---------------------------------------
  " Retira os ^M que ficam no final de arquivos salvos pelo windows.
  "---------------------------------------
  nmap <leader>m :%s/\r//g<cr>
  "---------------------------------------
  " Remove espaços redundantes no fim das linhas com \s
  "---------------------------------------
  nmap <leader>s mz:%s/\s\+$//g<cr>`z
  "---------------------------------------
  " Limpa o buffer de buscas
  "---------------------------------------
  nmap <leader>b :let @/=""<cr>
  "---------------------------------------
  " Atalhos Abas
  " 'Ctrl+t' abre uma nova aba
  "---------------------------------------
  imap <c-t> <esc>:tabnew<cr>
  nmap <c-t> :tabnew<cr>
  "---------------------------------------
  " permite indentar bloco de texto selecionado usando 'tab'
  " com guia e desindentar usando 'shift + tab'
  "---------------------------------------
  imap <s-tab> <c-o><lt><lt>
  nmap <tab> >>
  nmap <s-tab> <lt><lt>
  vmap <tab> >>
  vmap <s-tab> <lt>
  "---------------------------------------
	" Mostra ou não a identacão
	"---------------------------------------
	"set listchars=tab:¦·,trail:·,eol:$
	"set listchars=tab:▸·,trail:·,eol:¬
	"set listchars=tab:¦\ ,trail:·,eol:¬
	set listchars=trail:⋅,eol:↴
	"set list
	nmap <leader>i :set list!<cr>
]])

keymap.set('', '<up>', '<nop>', {noremap = true})
keymap.set('', '<down>', '<nop>', {noremap = true})
keymap.set('', '<left>', '<nop>', {noremap = true})
keymap.set('', '<right>', '<nop>', {noremap = true})

keymap.set('i', '<C-h>', '<left>', {noremap = true})
keymap.set('i', '<C-j>', '<down>', {noremap = true})
keymap.set('i', '<C-k>', '<up>', {noremap = true})
keymap.set('i', '<C-l>', '<right>', {noremap = true})

keymap.set('n', 'x', '"_x')

-- Increment/decrement
keymap.set('n', '+', '<C-a>')
keymap.set('n', '-', '<C-x>')

-- Delete a word backwards
keymap.set('n', 'dw', 'vb"_d')

-- Select all
keymap.set('n', '<C-a>', 'gg<S-v>G')

-- Save with root permission (not working for now)
--vim.api.nvim_create_user_command('W', 'w !sudo tee > /dev/null %', {})

-- New tab
keymap.set('n', 'te', ':tabedit')
-- Split window
keymap.set('n', 'ss', ':split<Return><C-w>w')
keymap.set('n', 'sv', ':vsplit<Return><C-w>w')
-- Move window
keymap.set('n', '<Space>', '<C-w>w')
keymap.set('', 'sh', '<C-w>h')
keymap.set('', 'sk', '<C-w>k')
keymap.set('', 'sj', '<C-w>j')
keymap.set('', 'sl', '<C-w>l')

-- Resize window
keymap.set('n', '<C-w><left>', '<C-w><')
keymap.set('n', '<C-w><right>', '<C-w>>')
keymap.set('n', '<C-w><up>', '<C-w>+')
keymap.set('n', '<C-w><down>', '<C-w>-')

-- Unless you are still migrating, remove the deprecated commands from v1.x
cmd([[ let g:neo_tree_remove_legacy_commands = 1 ]])

map("n", "<F5>", ":Neotree toggle<CR>", opts)
