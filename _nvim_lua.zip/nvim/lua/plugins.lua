local status, packer = pcall(require, "packer")
if (not status) then
  print("Packer is not installed")
  return
end

vim.cmd [[
	packadd packer.nvim
	"---------------------------------------
	" ALE
	"---------------------------------------
	let g:ale_completion_enabled = 1
	let g:ale_sign_error = '❌'
	let g:ale_sign_warning = '⚠️'
	"
	"let g:ale_linters = {
	"\   'javascript': ['eslint']
	"\}
	"
	"let g:ale_fixers = {
	"\ 'javascript': ['eslint']
	"\ }
	"
	"let g:ale_fixers = {
	"\   '*': ['trim_whitespace'],
	"\}
	"
	"let g:ale_fix_on_save = 1
]]

packer.startup(function(use)
  use 'wbthomason/packer.nvim'
  use {
    'svrana/neosolarized.nvim',
    requires = { 'tjdevries/colorbuddy.nvim' }
  }
  use 'nvim-lualine/lualine.nvim' -- Statusline
  use 'nvim-lua/plenary.nvim' -- Common utilities
  use 'onsails/lspkind-nvim' -- vscode-like pictograms
  use 'hrsh7th/cmp-buffer' -- nvim-cmp source for buffer words
  use 'hrsh7th/nvim-cmp' -- Completion
  use 'williamboman/mason.nvim'
  use 'kyazdani42/nvim-web-devicons' -- File icons
  use 'nvim-telescope/telescope.nvim'
  use 'nvim-telescope/telescope-file-browser.nvim'
  use 'windwp/nvim-autopairs'
  use 'norcalli/nvim-colorizer.lua'
  use 'folke/zen-mode.nvim'
  use({
    "iamcco/markdown-preview.nvim",
    run = function() vim.fn["mkdp#util#install"]() end,
  })
  use 'akinsho/nvim-bufferline.lua'
  -- use 'github/copilot.vim'
  use 'lewis6991/gitsigns.nvim'
  use 'dinhhuy258/git.nvim' -- For git blame & browse
  use "lukas-reineke/indent-blankline.nvim"
  use {
		"nvim-neo-tree/neo-tree.nvim",
		 branch = "v2.x",
		 requires = { 
		   "nvim-lua/plenary.nvim",
		   "nvim-tree/nvim-web-devicons", -- not strictly required, but recommended
		   "MunifTanjim/nui.nvim",
		 }
  }
  use 'dstein64/nvim-scrollview'
end)
